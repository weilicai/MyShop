package cn.itcast.dao;

import cn.itcast.entity.Adm;

public interface AdmDao {

	Adm login(Adm adm);

}
